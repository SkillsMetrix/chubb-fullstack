import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-reactiveapp',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './reactiveapp.component.html',
  styleUrl: './reactiveapp.component.css'
})
export class ReactiveappComponent {
addUser(data:any){

}
}
