import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { ReactiveappComponent } from '../reactiveapp/reactiveapp.component';

@Component({
  selector: 'app-mainapp',
  standalone: true,
  imports: [HeaderComponent,FooterComponent,ReactiveappComponent],
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {

}
