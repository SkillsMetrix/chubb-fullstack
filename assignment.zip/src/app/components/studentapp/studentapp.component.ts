import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-studentapp',
  templateUrl: './studentapp.component.html',
  styleUrl: './studentapp.component.css'
})
export class StudentappComponent {

  myForm: FormGroup
  empName: FormControl
  empEmail: FormControl
  empCity: FormControl

  createFormControls() {
    this.empName = new FormControl('', Validators.required)
    this.empEmail = new FormControl('', [Validators.required, Validators.email])
    this.empCity = new FormControl('', [Validators.required, Validators.minLength(6)])
  }
  createForm() {
    this.myForm = new FormGroup({
      empName: this.empName,
      empEmail: this.empEmail,
      empCity: this.empCity
    })
  }
  users: any[] = []
  constructor() {

    this.createFormControls()
    this.createForm()
    
  }
  addUser() {

   

  }
}

