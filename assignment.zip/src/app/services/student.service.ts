import { Injectable } from '@angular/core';
import { Student } from '../models/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private readonly storageKey = 'students'

  getStudentsData(): Student[] {
    const studentData = localStorage.getItem(this.storageKey)
    return studentData ? JSON.parse(studentData) : []

  }
  addStudent(student: Student) {
    const studentData = this.getStudentsData()
    studentData.push(student)
    localStorage.setItem(this.storageKey, JSON.stringify(student))
  }
  generateAutoID(): number {
    const studentData = this.getStudentsData()
    return studentData.length > 0 ? Math.max(...studentData.map((data) => data.id)) + 1 : 1
  }

  constructor() { }
}
