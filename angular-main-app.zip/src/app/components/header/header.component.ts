import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppserviceService } from '../../appservice.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  constructor(private service:AppserviceService){

  }

  username='Administrator'
  users=['admin','manager','QA']
  city='Mumbai'
  addUser(){
    alert('user added')
  }
}

