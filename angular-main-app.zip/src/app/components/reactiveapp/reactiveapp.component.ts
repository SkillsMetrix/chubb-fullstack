import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AppserviceService } from '../../appservice.service';

@Component({
  selector: 'app-reactiveapp',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './reactiveapp.component.html',
  styleUrl: './reactiveapp.component.css'
})
export class ReactiveappComponent {
  myForm: FormGroup
  empName: FormControl
  empEmail: FormControl
  empCity: FormControl

  createFormControls() {
    this.empName = new FormControl('', Validators.required)
    this.empEmail = new FormControl('', [Validators.required, Validators.email])
    this.empCity = new FormControl('', [Validators.required, Validators.minLength(6)])
  }
  createForm() {
    this.myForm = new FormGroup({
      empName: this.empName,
      empEmail: this.empEmail,
      empCity: this.empCity
    })
  }
  users: any[] = []
  constructor(private service: AppserviceService) {

    this.createFormControls()
    this.createForm()
    this.loadData()
  }
  addUser() {

    this.service.addUser(this.myForm.value)
    this.loadData()

  }
  loadData() {
    this.service.loadUsers().subscribe((res) => {
      const myarray = []
      for (let key in res) {
        myarray.push(res[key])

      }
      this.users = myarray

    })
  }
}
