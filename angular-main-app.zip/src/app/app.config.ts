import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { ErrorInterceptor } from './shared/ErrorInterceptor';
import { LoggerInterceptor } from './shared/LoggerInterceptor';
 
 
export const appConfig: ApplicationConfig = {
  providers: [provideHttpClient(withInterceptors([])),provideZoneChangeDetection({ eventCoalescing: true })]
};
