import { HttpErrorResponse, HttpEvent, HttpEventType, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { } from '@angular/common/http'
import { Injectable } from "@angular/core";
import { catchError, Observable, tap, throwError } from "rxjs";
@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log(`Error URL ${req.url}`);
        return next.handle(req)
        .pipe(
            catchError((error: HttpErrorResponse)=>{
                if(error instanceof HttpErrorResponse){
                    console.log('caught', error);
                    
                    //server error
                    return throwError(error)
                }else{
                    //client side
                    return throwError(error)
                }
            })
        )
             

    }
}