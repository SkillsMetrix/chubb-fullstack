import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppserviceService {

  URL='http://localhost:8090'
  constructor(private http: HttpClient) {

  }

  addUser(data: any) {
    console.log(data);
    this.http.post(`${this.URL}\emp\data`, data)
      .subscribe((data) => {
        console.log(data);

      })

  }
  loadUsers(){
    return this.http.get("http://localhost:8090/emp/loadall")
  }
  deleteUser(id:number){
    return this.http.delete(`http://localhost:8090/emp/deleteemp/${id}`)
  }

}
