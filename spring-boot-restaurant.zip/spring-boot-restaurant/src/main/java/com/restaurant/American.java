package com.restaurant;

import org.springframework.stereotype.Component;

@Component(value = "am")
public class American implements Restaurant{

	@Override
	public String prepareFood(String dishName) {
 	return "preparing "+ dishName + " with lots of cheese and breads";

	}

}
