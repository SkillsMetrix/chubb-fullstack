package com.restaurant;

import org.springframework.stereotype.Component;

@Component(value = "ir")
public class IndianRestaurant implements Restaurant{

	@Override
	public String prepareFood(String dishName) {
		
		return "preparing "+ dishName + " with indian herbs and spices";
	}

}
