package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.laundry.Laundry;
@Service(value = "ls")
public class LaundryService {
@Autowired
@Qualifier("stl")
	public Laundry laundry;
 
	public String washClothes(String input) {
		return laundry.washClothes(input);
	}

}
