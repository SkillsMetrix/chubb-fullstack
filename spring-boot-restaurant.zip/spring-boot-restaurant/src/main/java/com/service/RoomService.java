package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.restaurant.Restaurant;
@Service(value = "rs")
public class RoomService {
	
	@Autowired
	@Qualifier("am")
	public Restaurant restaurant;

	
	
	public String placeOrder(String dishName) {
		return restaurant.prepareFood(dishName);
	}

}
