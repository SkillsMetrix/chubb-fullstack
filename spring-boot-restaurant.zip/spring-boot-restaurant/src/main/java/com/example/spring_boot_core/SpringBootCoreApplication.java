package com.example.spring_boot_core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.service.LaundryService;
import com.service.RoomService;

@ComponentScan("com")
public class SpringBootCoreApplication {
	 

	public static void main(String[] args) {
 		ApplicationContext ctx= new AnnotationConfigApplicationContext(SpringBootCoreApplication.class);
		RoomService service=(RoomService)ctx.getBean("rs");
		RoomService service2=(RoomService)ctx.getBean("rs");
		
		System.out.println(service.hashCode());
		System.out.println(service2.hashCode());

		System.out.println(service.placeOrder("Burger"));
		
		
		LaundryService lsc= (LaundryService)ctx.getBean("ls");
		//System.out.println(lsc.washClothes("shirt"));
		 
		
		
	}

}
