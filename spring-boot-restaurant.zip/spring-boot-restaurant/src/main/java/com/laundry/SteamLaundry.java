package com.laundry;

import org.springframework.stereotype.Component;

@Component(value = "st")
public class SteamLaundry implements Laundry {

	@Override
	public String washClothes(String clothes) {
		// TODO Auto-generated method stub
		return "Steam washed "+ clothes;
	}

}
