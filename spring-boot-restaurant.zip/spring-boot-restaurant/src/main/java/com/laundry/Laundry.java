package com.laundry;

public interface Laundry {
	
	public String washClothes(String clothes);

}
