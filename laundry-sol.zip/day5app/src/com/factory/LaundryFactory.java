package com.factory;

import com.laundry.Laundry;
import com.laundry.StandardLaundry;
import com.laundry.SteamLaundry;

public class LaundryFactory {

	public static Laundry createInstance(char input) {
		switch (input) {
		case 's': {

			return new StandardLaundry();
		}
		case 'p': {

			return new SteamLaundry();
		}
		default:
			return null;
		}
	}

}
