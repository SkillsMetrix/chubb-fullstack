package com.laundry;

public class StandardLaundry implements Laundry {

	@Override
	public String washClothes(String clothes) {
		// TODO Auto-generated method stub
		return "Standard washed "+ clothes;
	}

}
