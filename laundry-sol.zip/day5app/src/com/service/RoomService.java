package com.service;

import com.restaurant.Restaurant;

public class RoomService {
	
	public Restaurant restaurant;

	public RoomService(Restaurant restaurant) {

		this.restaurant = restaurant;
	}
	
	public String placeOrder(String dishName) {
		return restaurant.prepareFood(dishName);
	}

}
