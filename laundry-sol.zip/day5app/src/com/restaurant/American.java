package com.restaurant;

public class American implements Restaurant{

	@Override
	public String prepareFood(String dishName) {
 	return "preparing "+ dishName + " with lots of cheese and breads";

	}

}
