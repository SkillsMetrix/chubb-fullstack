package com.dao;

import java.util.List;

import com.entity.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee);
	public List<Employee>loadall();
	public boolean findEmployee(int empId);
	public boolean deleteEmployee(int empId);
	public void updateEmployee(String project,int empid);




}
