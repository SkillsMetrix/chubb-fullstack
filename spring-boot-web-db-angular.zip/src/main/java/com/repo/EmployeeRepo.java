package com.repo;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.Employee;
@Repository
// this class will provide useful methods to perform operations on DATABASE
public interface EmployeeRepo extends CrudRepository<Employee, Integer>{
	@Transactional
	@Modifying
	@Query("update Employee e set e.empCity=:empCity where e.empId=:empId")
	
	public int updateEmployee(@Param("empCity")String empCity,@Param("empId")int empId);

}
