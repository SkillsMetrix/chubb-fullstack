package com.guest;

import com.factory.RestaurantFactory;
import com.restaurant.American;
import com.restaurant.IndianRestaurant;
import com.service.RoomService;

public class RoomGuest {
	public static void main(String[] args) {
		
		RoomService roomService= new RoomService(RestaurantFactory.createRestaurant('i'));
		System.out.println(roomService.placeOrder("Chicken "));
	}

}
