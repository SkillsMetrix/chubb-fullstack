package interfacedemo;

public interface SimpleCalc {
	
	void show();

}
