package interfacedemo;

public class CalcMain {
	public static void main(String[] args) {
		
		Calculator calculator= new MathCalc();
		System.out.println(calculator.sum(10,20 ));
	}

}
