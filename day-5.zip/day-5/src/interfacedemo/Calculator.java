package interfacedemo;

public interface Calculator {
	
	
	//in interface all methods are by default public and abstract
	
	public abstract int sum(int x,int y);
	int sub(int x,int y);
	//define constants
	public static final int USER_AGE=23;
	
	

}
