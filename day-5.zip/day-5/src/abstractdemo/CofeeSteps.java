package abstractdemo;

public abstract class CofeeSteps {
	
	public abstract void takeCup();
	public abstract void addCoffeePowder();
	public abstract void addWater();
	public abstract void serveIt();
	public abstract void makeItHot();
	
	public  void addSugar() {
		System.out.println("add sugar optional");
	}
	}
