package abstractdemo;

public class CoffeeMain {
	public static void main(String[] args) {
		
		CofeeSteps americano= new Americano();
		CofeeSteps capu= new Capu();
		CofeeSteps expres= new Expres();
		
		// take a note , abstract classes cant be instantiate
		
		//CofeeSteps cofeeSteps= new CofeeSteps();
		
		
		americano.takeCup();
		americano.addWater();
		americano.addCoffeePowder();
		americano.makeItHot();
		americano.serveIt();
	}

}
