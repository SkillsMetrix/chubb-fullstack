package inheritence;

public class CItiBank extends Bank{
	
	public CItiBank(){
		System.out.println("inside citi");
	}
	
	public void openLocker() {
		System.out.println("Locker Opened");
	}

}
