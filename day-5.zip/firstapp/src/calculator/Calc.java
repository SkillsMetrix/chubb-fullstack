package calculator;

public class Calc {

	public static void main(String[] args) {
		
             int firstNumber=Integer.parseInt( args[0]);
             if(firstNumber <= 0) {
            	 System.out.println("please enter valid value");
             }
             int secondNumber=Integer.parseInt( args[1]);
             
             int c=firstNumber+secondNumber;
             System.out.println("Addition is  "+ c);
             
             
	}

}
