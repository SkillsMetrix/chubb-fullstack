package com.example.spring_boot_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
// this annotation launch the server and load all the configuration files
@SpringBootApplication
@ComponentScan("com")
public class SpringBootCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCoreApplication.class, args);
		
		
	}

}
