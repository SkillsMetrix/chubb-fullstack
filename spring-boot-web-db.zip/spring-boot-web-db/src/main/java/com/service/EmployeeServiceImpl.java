package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.EmployeeDao;
import com.entity.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao;

	@Override
	public void addEmployee(Employee employee) {
		dao.addEmployee(employee);
		
	}

	@Override
	public List<Employee> loadEmployees() {
		// TODO Auto-generated method stub
		return dao.loadall();
	}

	@Override
	public boolean findEmployee(int empId) {
		// TODO Auto-generated method stub
		return dao.findEmployee(empId);
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empId);
	}

	@Override
	public void updateEmployee(String project, int empid) {
		dao.updateEmployee(project, empid);
		
	}

	 

}
