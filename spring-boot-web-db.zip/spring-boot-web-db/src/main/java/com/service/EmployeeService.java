package com.service;

import java.util.List;

import com.entity.Employee;

public interface EmployeeService {
	
	public void addEmployee(Employee employee);
	public List<Employee> loadEmployees();
	public boolean findEmployee(int empId);
	public boolean deleteEmployee(int empId);
	public void updateEmployee(String project,int empid);



}
