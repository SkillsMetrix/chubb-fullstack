package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entity.Employee;
import com.repo.EmployeeRepo;
@Component
public class EmployeeDaoImpl implements EmployeeDao{
	@Autowired
	private EmployeeRepo repo;

	@Override
	public void addEmployee(Employee employee) {
		repo.save(employee);
		
	}

	@Override
	public List<Employee> loadall() {
		// TODO Auto-generated method stub
		return (List<Employee>) repo.findAll();
	}

	@Override
	public boolean findEmployee(int empId) {
		  Optional<Employee> data= repo.findById(empId);
		  if(data.isPresent()) {
			  return true;
		  }
		return false;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		 Optional<Employee> data= repo.findById(empId);
		  if(data.isPresent()) {
			  repo.deleteById(empId);
			  return true;
		  }
		return false;
	}

	@Override
	public void updateEmployee( String empProject,int empId) {
		 repo.updateEmployee(empProject, empId);
		
	}
	

}
