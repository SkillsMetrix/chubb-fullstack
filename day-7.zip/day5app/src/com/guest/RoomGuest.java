package com.guest;

import com.factory.LaundryFactory;
import com.factory.RestaurantFactory;
import com.restaurant.American;
import com.restaurant.IndianRestaurant;
import com.service.LaundryService;
import com.service.RoomService;

public class RoomGuest {
	public static void main(String[] args) {
		
		RoomService roomService= new RoomService(RestaurantFactory.createRestaurant('i'));
		System.out.println(roomService.placeOrder("Chicken "));
		
		LaundryService laundryService=new LaundryService(LaundryFactory.createInstance('s'));
		System.out.println(laundryService.washClothes("Jeans and T-Shirt"));
		
		
		roomService=null;
		laundryService=null;
		
	}

}
