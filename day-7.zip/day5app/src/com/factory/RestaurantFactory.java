package com.factory;

import com.restaurant.American;
import com.restaurant.IndianRestaurant;
import com.restaurant.Restaurant;

public class RestaurantFactory {
	// can access this fun directly with the class name
	public static Restaurant createRestaurant(char input) {
		switch (input) {
		case 'i':
			return new IndianRestaurant();
		case 'a':
			return new American();
		default:
			return null;

		}
	}

}
