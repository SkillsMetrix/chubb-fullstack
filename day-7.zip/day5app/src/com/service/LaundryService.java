package com.service;

import com.laundry.Laundry;

public class LaundryService {

	public Laundry laundry;

	public LaundryService(Laundry laundry) {

		this.laundry = laundry;
	}

	public String washClothes(String input) {
		return laundry.washClothes(input);
	}

}
