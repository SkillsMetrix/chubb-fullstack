package bank;

public class BankingMain {
	
	public static void main(String[] args) {
		
		// creating an object of Banking
		
		Banking boa= new Banking();
		System.out.println(boa.hashCode());
		//boa.transferFunds(101, 102, 50);
		
		Banking jpmc= new Banking();
		//jpmc.transferFunds(101, 102, 50);
		System.out.println(jpmc.hashCode());
		 

		
		
	
		
	}

}
