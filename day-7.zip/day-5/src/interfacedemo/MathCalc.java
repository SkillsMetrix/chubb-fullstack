package interfacedemo;

public class MathCalc implements Calculator{

	@Override
	public int sum(int x, int y) {
		 
		return x+y;
	}

	@Override
	public int sub(int x, int y) {
		// TODO Auto-generated method stub
		return 0;
	}

}
