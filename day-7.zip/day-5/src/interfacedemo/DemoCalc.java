package interfacedemo;

public class DemoCalc implements Calculator,SimpleCalc{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int sum(int x, int y) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int sub(int x, int y) {
		// TODO Auto-generated method stub
		return 0;
	}

}
