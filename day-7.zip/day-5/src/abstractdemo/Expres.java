package abstractdemo;

public class Expres extends CofeeSteps{

	@Override
	public void takeCup() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addCoffeePowder() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addWater() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serveIt() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makeItHot() {
		// TODO Auto-generated method stub
		
	}

}
