package abstractdemo;

public class Americano extends CofeeSteps{

	@Override
	public void takeCup() {
		System.out.println("medium cup taken");
		
	}

	@Override
	public void addCoffeePowder() {
System.out.println("add strong coffee");		
	}

	@Override
	public void addWater() {
		System.out.println("add little water");
		
	}

	@Override
	public void serveIt() {
		System.out.println("Served it hot.....");
		
	}

	@Override
	public void makeItHot() {
		System.out.println("steamed well");
		
	}
	
}
