package firstapp;

public class WhileDemo {

	public static void main(String[] args) {
		int count=0;
		while(count <10) {
			System.out.println("Count "+ count);
			count++;
		}
	}
}
