package firstapp;

public class ForLoopDemo {
	
	public static void main(String[] args) {
		
		//String[] cars= {"merc","BMW","Ford"};
		int [] userAge= {22,34,54,12,10};
		/*
		 * for(String carData: cars) { //System.out.println(carData); }
		 * 
		 * for(int ages: userAge) { //System.out.println("User Age "+ ages); } // get
		 * the length of array System.out.println(userAge.length); // store the first
		 * array element int lowestAge=userAge[0]; //loop through the elements of the
		 * userage to find the lowest age for(int age:userAge) { //check if the current
		 * age is smaller than the "Lowestage" if(lowestAge > age) { // if the smaller
		 * age is found update the "lowest age" element lowestAge =age; } }
		 * System.out.println("The Lowest age found is "+ lowestAge);
		 */
		
	int sum=0;
	int i=0;
		for(i=0;i<userAge.length;i++)
			sum +=userAge[i];
	System.out.println(sum);
		
		 
	}

}
