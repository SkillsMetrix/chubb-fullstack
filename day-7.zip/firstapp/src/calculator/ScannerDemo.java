package calculator;

import java.util.Scanner;

public class ScannerDemo {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		// string input type
		String name = scanner.nextLine();

		// char read
		char gender = scanner.next().charAt(0);

		int age = scanner.nextInt();
		long mobile = scanner.nextLong();
		double cgpa = scanner.nextDouble();

		System.out.println("Name " + name);
		System.out.println("gender " + gender);
		System.out.println("age " + age);
		System.out.println("mobile " + mobile);
		System.out.println("CGPA " + cgpa);

	}

}
