package com.nested;

public class DataStructure {
	// creating an array with constants

	private final static int FIXED_SIZE = 15;
	private int[] arrayOfData = new int[FIXED_SIZE];

	public DataStructure() {
		for (int i = 0; i < FIXED_SIZE; i++) {
			arrayOfData[i] = i;
		}
	}

	public void printEven() {
		InnerClass ic = new InnerClass();
		while (ic.hasNext()) {
			System.out.println("The Value " + ic.getNext() + " ");
		}

	}
	// starting inner class

	private class InnerClass {
		private int next = 0;

		public boolean hasNext() {
			return (next <= FIXED_SIZE - 1);
		}

		public int getNext() {
			int retValue = arrayOfData[next];
			next += 2;
			return retValue;
		}
	}

}
