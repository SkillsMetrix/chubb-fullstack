package com.nested;

public class DSMain {
	public static void main(String[] args) {
		DataStructure dataStructure= new DataStructure();
		dataStructure.printEven();
	}

}
