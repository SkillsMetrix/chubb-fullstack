package com.employee;

public class Employee {
	
	private int a;
	private int b;
	public Employee() {
		System.out.println("EMployee default Cons");
	}
	public Employee(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	@Override
	public String toString() {
		return "Employee [a=" + a + ", b=" + b + "]";
	}
	
	

}
