package com.employee;

public class EmployeeMain {
	
	public static void main(String[] args) {
		
		Employee employee= new Employee();
		
		Employee employee2= new Employee(12, 18);
		
		System.out.println(employee.hashCode());
		
		System.out.println(employee2.hashCode());
		
		employee2=employee;
		
System.out.println(employee.hashCode());
		
		System.out.println(employee2.hashCode());
	}

}
