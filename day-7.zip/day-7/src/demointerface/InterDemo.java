package demointerface;

public class InterDemo implements Calculator,Calculator2{

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		Calculator.super.show();
	}

	 

}
