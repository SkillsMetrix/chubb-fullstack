package demointerface;

public interface Calculator2 {

	public default void show() {
		System.out.println("normal method in calculator-2");
	}
}
