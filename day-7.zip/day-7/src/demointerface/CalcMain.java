package demointerface;

public class CalcMain {

	public static void main(String[] args) {
		
		InterDemo demo= new InterDemo();
		
		System.out.println(demo.add(12, 13));
		demo.show();

	}

}
