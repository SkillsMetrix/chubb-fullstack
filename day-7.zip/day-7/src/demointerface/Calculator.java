package demointerface;

public interface Calculator {
	
	public int add(int a,int b);
	
	public default void show() {
		System.out.println("normal method");
	}

}
