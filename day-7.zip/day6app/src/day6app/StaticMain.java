package day6app;

public class StaticMain {
	
	public static void main(String[] args) {
		
	StaticApp.meth(40);
}
}