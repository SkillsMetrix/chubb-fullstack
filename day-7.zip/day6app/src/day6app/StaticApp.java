package day6app;

public class StaticApp {
	
	static int a=3;
	static int b;
	
	static void meth(int x) {
		System.out.println("called method");
		System.out.println("x= "+x);
		System.out.println("a= "+a);
		System.out.println("b= "+b);
	}
	
	static {
		System.out.println("Called Very First , even before Main method");
		b=a*4;
	}

}
