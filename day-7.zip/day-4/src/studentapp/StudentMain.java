package studentapp;

public class StudentMain {
	
	public static void main(String[] args) {
		Student stud= new Student();
		stud.setRollNo(101);
		stud.setStudentClass("");
		stud.setSubject("");
		
	}
		 

}
