package pack2;

public class EmployeeMain {
	
	public static void main(String[] args) {
		// this will invoke default
		Employee myemployee= new Employee();
		
		Employee emp= new Employee(101, "Admin", "NY", "IT");
		
		System.out.println(emp);
	
		
	}

}
