package inheritence;

public class BankMain {
	
	public static void main(String[] args) {
		
		CItiBank bank= new CItiBank();
		
		bank.checkBalance(100);
		bank.deposit(234);
		bank.withdraw(200);
		bank.openLocker();
	}

}
