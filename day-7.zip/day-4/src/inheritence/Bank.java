package inheritence;

public class Bank {
	// cons never return and the share the same name as class
	public Bank() {
		System.out.println("Inside Bank class");
	}
	public void deposit(int amount) {
		System.out.println("Amount Deposited");
	}
	public void withdraw(int amount) {
		System.out.println("Amount Withdrawn");
	}
	public void checkBalance(int amount) {
		System.out.println("Balance Checked");
	}

}
