package com.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class CustomExceptionHandler {
	@ExceptionHandler(ServletRequestBindingException.class)
	public ResponseEntity<Object> handleHeaderMissingException(Exception exception,WebRequest request){
		
		List<String> details= new ArrayList<String>();
		details.add(exception.getLocalizedMessage());
		ErrorResponse res= new ErrorResponse("OOPS... Header is Missing", details);
		return new ResponseEntity(res,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> genericException(Exception exception,WebRequest request){
		
		List<String> details= new ArrayList<String>();
		details.add(exception.getLocalizedMessage());
		ErrorResponse res= new ErrorResponse("OOPS...PLease check the method type", details);
		return new ResponseEntity(res,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
