package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.model.User;
import com.repo.UserRepo;
 
@Service
public class UserDaoImpl implements UserDao {
	@Autowired
	private UserRepo repo;
	
	 
	@Override
	public List<User> loadUsers() {
		// TODO Auto-generated method stub
		return (List<User>) repo.findAll();
	}

	@Override
	public void addUser(User user) {
		repo.save(user);
		
	}

}
