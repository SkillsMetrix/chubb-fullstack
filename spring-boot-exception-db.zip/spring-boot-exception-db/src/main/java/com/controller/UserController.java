package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.User;

import com.service.UserDaoImpl;

@RestController
@RequestMapping("/user")
public class UserController {
	
	 
	@Autowired
	private UserDaoImpl dao;

	@GetMapping("/users")
	
	public List<User> loadusers(
			@RequestHeader(name="X-COM-PERSIST",required = true)String per,
			@RequestHeader(name="X-LOCATION",defaultValue = "ASIA")String loc
			) {
		return dao.loadUsers();
}
	
 @PostMapping("/adduser")
public String addUsers(@RequestBody User user) {
	dao.addUser(user);
	return "user added";
}

}
